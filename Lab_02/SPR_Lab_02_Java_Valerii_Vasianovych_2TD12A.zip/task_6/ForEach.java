public class ForEach {
    public static void main(String[] args) {
        int[] numbers = {11, 22, 33, 44, 55};

        for (int num : numbers) {
            System.out.println(num);
        }
    }
}