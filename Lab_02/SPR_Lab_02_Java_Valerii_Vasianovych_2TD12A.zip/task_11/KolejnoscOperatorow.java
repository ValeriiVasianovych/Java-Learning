class KolejnoscOperatorow {
    public static void main(String[] args) {
        int result = 12 + 5 * 4 / 8 - 1;
        System.out.println("Wynik działania: " + result);
    }
}