package labs.Lab_01.task_1;

// Klasa ProgramPierwszy
public class ProgramPierwszy {
	// Metoda main
	public static void main(String[] args)
	{
		// Ta linijka wypisze "Witaj Świecie!" na konsoli
		System.out.println("Witaj Świecie!");
	}
}
