public class ProgramPierwszy {
	public static void main(String[] args)
	{
		System.out.println("Witaj Świecie!");
	}
}
